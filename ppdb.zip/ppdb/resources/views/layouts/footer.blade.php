<footer class="container">
  <p>&copy; sangcahaya.com</p>
</footer>