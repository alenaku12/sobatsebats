<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bukti Pendaftaran</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
 
    <!-- <link rel="stylesheet" href="<?php echo e(asset('adminlte/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>"> -->
 
   
   
</head>
<body>
   
	<div class="container">
		<center>
			<img src="<?php echo e(asset($sk->photo)); ?>" style="width: 200px;">
		</center>
		<br>
		<br>
		<div class="row">
			<div class="col-md-12">
				<table class="table">
					<tbody>
						<tr>
							<th>Nama Sekolah</th>
							<td>:</td>
							<td><?php echo e($sk->nama); ?></td>

							<th style="padding-left: 50px;">Alamat</th>
							<td>:</td>
							<td><?php echo e($sk->alamat); ?></td>
						</tr>

						<tr>
							<th>No Telp</th>
							<td>:</td>
							<td><?php echo e($sk->no_telp); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<br>
		<hr>
		<br>

		<div class="row">
			<div class="col-md-12">
				<table class="table">
					<thead>
						<tr>
							<th width="100">Nama</th>
							<th width="100">Email</th>
							<th width="100">Alamat</th>
							<th width="100">No HP</th>
							<th width="100">Tempat Lahir</th>
							<th width="100">ID Pendaftaran</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><?php echo e($dt->name); ?></td>
							<td><?php echo e($dt->email); ?></td>
							<td><?php echo e($dt->biodata_r->alamat); ?></td>
							<td><?php echo e($dt->biodata_r->no_hp); ?></td>
							<td><?php echo e($dt->biodata_r->tempat_lahir); ?></td>
							<td><?php echo e($dt->id_registrasi); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>

</body>
</html><?php /**PATH /var/www/html/ppdb/resources/views/dashboard/biodata/pdf.blade.php ENDPATH**/ ?>