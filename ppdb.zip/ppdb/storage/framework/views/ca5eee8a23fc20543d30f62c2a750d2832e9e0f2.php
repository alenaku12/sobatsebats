<footer class="container">
  <p>&copy; sangcahaya.com</p>
</footer><?php /**PATH /var/www/html/ppdb/resources/views/layouts/footer.blade.php ENDPATH**/ ?>