<?php $__env->startSection('content'); ?>

<!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="jumbotron">
    <div class="container">
      <h1 class="display-3">Selamat Datang!</h1>
      <p>Silahkan klik button dibawah ini untuk melakukan pendaftaran PPDB Online</p>
      <p><a class="btn btn-primary btn-lg" href="<?php echo e(url('ppdb')); ?>" role="button">PPDB &raquo;</a></p>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdb/resources/views/welcome.blade.php ENDPATH**/ ?>