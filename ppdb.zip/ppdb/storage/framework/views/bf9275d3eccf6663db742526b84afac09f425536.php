 
<?php $__env->startSection('content'); ?>
 
<div class="row">
    <div class="col-md-12">
        <h4><?php echo e($title); ?></h4>
        <div class="box box-warning">
            <div class="box-header">
                <p>
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>

                    <a href="<?php echo e(url('pesan')); ?>" class="btn btn-sm btn-flat btn-primary"><i class="fa fa-refresh"></i> Kembali</a>
                </p>
            </div>
            <div class="box-body">
               <table class="table table-hover">
                   <tbody>
                       <tr>
                           <th>Judul</th>
                           <td>:</td>
                           <td><?php echo e($dt->judul); ?></td>

                           <th>Users</th>
                           <td>:</td>
                           <td><?php echo e($dt->users_r->name); ?></td>

                           <th>Tanggal</th>
                           <td>:</td>
                           <td><?php echo e(date('d M Y H:i:s',strtotime($dt->created_at))); ?></td>
                       </tr>

                       <tr>
                           <th>Isi Pesan</th>
                           <td>:</td>
                           <td><?php echo $dt->keterangan; ?></td>
                       </tr>
                   </tbody>
               </table>
            </div>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('scripts'); ?>
 
<script type="text/javascript">
    $(document).ready(function(){
 
        // btn refresh
        $('.btn-refresh').click(function(e){
            e.preventDefault();
            $('.preloader').fadeIn();
            location.reload();
        })
 
    })
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdb/resources/views/dashboard/pesan/detail.blade.php ENDPATH**/ ?>