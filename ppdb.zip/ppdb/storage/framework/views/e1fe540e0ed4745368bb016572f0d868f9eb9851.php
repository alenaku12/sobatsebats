 
<?php $__env->startSection('content'); ?>
 
<div class="row">
    <div class="col-md-12">
        <h4><?php echo e($title); ?></h4>
        <div class="box box-warning">
            <div class="box-header">
                <p>
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>

                    <a href="<?php echo e(url('peserta')); ?>" class="btn btn-sm btn-flat btn-primary"><i class="fa fa-refresh"></i> All Peserta</a>

                    <a href="<?php echo e(url('peserta/verifikasi')); ?>" class="btn btn-sm btn-flat btn-success"><i class="fa fa-refresh"></i> Di verfifikasi</a>

                    <a href="<?php echo e(url('peserta/belum-verifikasi')); ?>" class="btn btn-sm btn-flat btn-danger"><i class="fa fa-refresh"></i> Belum Di verfifikasi</a>
                </p>
            </div>
            <div class="box-body">
               
                <div class="table-responsive">
                    <table class="table table-hover" id="table-datatables">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>action</th>
                                <th>photo</th>
                                <th>name</th>
                                <th>nisn</th>
                                <th>email</th>
                                <th>id registrasi</th>
                                <th>no hp</th>
                                <th>alamat</th>
                                <th>is melengkapi??</th>
                                <th>is verifikasi??</th>
                                <th>Download</th>
                                <th>is lulus?</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e=>$dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($e+1); ?></td>
                                <td>
                                        <div style="width:60px">
                                            <a href="<?php echo e(url('peserta/detail/'.$dt->id)); ?>" class="btn btn-success btn-xs btn-edit" id="edit"><i class="fa fa-eye"></i></a>

                                            <a href="<?php echo e(url('peserta/'.$dt->id)); ?>" class="btn btn-warning btn-xs btn-edit" id="edit"><i class="fa fa-pencil-square-o"></i></a>

                                            <button href="<?php echo e(url('peserta/'.$dt->id)); ?>" class="btn btn-danger btn-xs btn-hapus" id="delete"><i class="fa fa-trash-o"></i></button>
                                        </div>
                                </td>
                                <td>
                                    <img src="<?php echo e(asset($dt->photo)); ?>" style="width: 100px;">
                                </td>
                                <td><?php echo e($dt->name); ?></td>
                                <td><?php echo e($dt->nisn); ?></td>
                                <td><?php echo e($dt->email); ?></td>
                                <td><?php echo e($dt->id_registrasi); ?></td>
                                <td><?php echo e($dt->biodata_r->no_hp); ?></td>
                                <td><?php echo e($dt->biodata_r->alamat); ?></td>
                                <?php if($dt->biodata_r_count > 0): ?>
                                <td>
                                    <label class="label label-success">Sudah Melengkapi</label>
                                </td>
                                <?php else: ?>
                                <td>
                                    <label class="label label-danger">Belum Melengkapi</label>
                                </td>
                                <?php endif; ?>

                                <?php if($dt->is_verifikasi == 1): ?>
                                <td>
                                    <label class="label label-success">Sudah Diverifikasi</label>
                                </td>
                                <?php else: ?>
                                <td>
                                    <label class="label label-danger">Belum Diverifikasi</label>
                                </td>
                                <?php endif; ?>

                                <td>
                                    <p>
                                        <a href="<?php echo e(asset($dt->biodata_r->ijazah)); ?>" class="btn btn-xs btn-success" download="">Download Ijazah</a>

                                        <a href="<?php echo e(asset($dt->biodata_r->ktp)); ?>" class="btn btn-xs btn-warning" download="">Download KTP</a>
                                    </p>
                                </td>

                                <td>
                                    <?php if($dt->is_lulus == null): ?>
                                    <a href="<?php echo e(url('peserta/'.$dt->id.'/lulus')); ?>" class="btn btn-xs btn-primary">Luluskan</a>
                                    <?php else: ?>
                                    <label class="label label-info">Sudah Lulus</label>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('scripts'); ?>
 
<script type="text/javascript">
    $(document).ready(function(){

        $('#table-datatables').DataTable({
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        });
 
        // btn refresh
        $('.btn-refresh').click(function(e){
            e.preventDefault();
            $('.preloader').fadeIn();
            location.reload();
        })
 
    })
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdb/resources/views/dashboard/peserta/index.blade.php ENDPATH**/ ?>