 
<?php $__env->startSection('content'); ?>
 
<div class="row">
    <div class="col-md-12">
        <h4><?php echo e($title); ?></h4>
        <div class="box box-warning">
            <div class="box-header">
                <p>
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>

                    <a href="<?php echo e(asset($dt->biodata_r->ijazah)); ?>" class="btn btn-success btn-sm btn-flat" download="">Download Ijazah</a>

                                        <a href="<?php echo e(asset($dt->biodata_r->ktp)); ?>" class="btn btn-primary btn-sm btn-flat" download="">Download KTP</a>

                    <a href="<?php echo e(url('peserta')); ?>" class="btn btn-sm btn-flat btn-danger"><i class="fa fa-backward"></i> Kembali</a>
                </p>
            </div>
            <div class="box-body">
               <div class="table-responsive">
                   <table class="table table-stripped">
                       <tbody>
                           <tr>
                               <th>Nama</th>
                               <td>:</td>
                               <td><?php echo e($dt->name); ?></td>

                               <th>NISN</th>
                               <td>:</td>
                               <td><?php echo e($dt->nisn); ?></td>

                               <th>Email</th>
                               <td>:</td>
                               <td><?php echo e($dt->email); ?></td>
                           </tr>
                           <tr>
                               
                               <th>ID Registrasi</th>
                               <td>:</td>
                               <td><?php echo e($dt->id_registrasi); ?></td>

                               <th>No HP</th>
                               <td>:</td>
                               <td><?php echo e($dt->biodata_r->no_hp); ?></td>

                               <th>Alamat</th>
                               <td>:</td>
                               <td><?php echo e($dt->biodata_r->alamat); ?></td>
                           </tr>
                       </tbody>
                   </table>
               </div>
            </div>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('scripts'); ?>
 
<script type="text/javascript">
    $(document).ready(function(){
 
        // btn refresh
        $('.btn-refresh').click(function(e){
            e.preventDefault();
            $('.preloader').fadeIn();
            location.reload();
        })
 
    })
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdb/resources/views/dashboard/peserta/detail.blade.php ENDPATH**/ ?>