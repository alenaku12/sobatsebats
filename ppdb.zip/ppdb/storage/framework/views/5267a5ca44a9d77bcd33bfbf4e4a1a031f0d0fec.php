 
<?php $__env->startSection('content'); ?>
 
<div class="row">
    <div class="col-md-12">
        <h4><?php echo e($title); ?></h4>
        <div class="box box-warning">
            <div class="box-header">
                <p>
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>
                </p>
            </div>
            <div class="box-body">
               
                <form role="form" method="post" action="<?php echo e(url('profile-sekolah')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Nama Sekolah</label>
                      <input type="text" name="nama" class="form-control" id="exampleInputEmail1" placeholder="Nama Sekolah" value="<?php echo e($dt->nama); ?>">
                    </div>

                    <div class="form-group">
                      <label for="exampleInputPassword1">No Telp</label>
                      <input type="text" name="no_telp" class="form-control" id="exampleInputPassword1" placeholder="No Telp" value="<?php echo e($dt->no_telp); ?>">
                    </div>

                    <div class="form-group">
                      <label for="exampleInputPassword1">Alamat</label>
                      <textarea class="form-control" name="alamat" rows="5"><?php echo e($dt->alamat); ?></textarea>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputFile">Logo Sekolah</label>
                      <input type="file" name="photo" id="exampleInputFile">
     
                      <p class="help-block">Example block-level help text here.</p>
                    </div>
                    
                  </div>
                  <!-- /.box-body -->
     
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Update</button>
                  </div>
                </form>

            </div>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('scripts'); ?>
 
<script type="text/javascript">
    $(document).ready(function(){
 
        // btn refresh
        $('.btn-refresh').click(function(e){
            e.preventDefault();
            $('.preloader').fadeIn();
            location.reload();
        })
 
    })
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdb/resources/views/dashboard/profile_sekolah/index.blade.php ENDPATH**/ ?>