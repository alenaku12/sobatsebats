 
<?php $__env->startSection('content'); ?>
 
<div class="row">
    <div class="col-md-12">
        <h4><?php echo e($title); ?></h4>
        <div class="box box-warning">
            <div class="box-header">
                <p>
                    <button class="btn btn-sm btn-flat btn-warning btn-refresh"><i class="fa fa-refresh"></i> Refresh</button>

                    <a href="<?php echo e(url('pesan/add')); ?>" class="btn btn-sm btn-flat btn-primary"><i class="fa fa-refresh"></i> Kirim Pesan</a>
                </p>
            </div>
            <div class="box-body">
               
                <table class="table table-hover myTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>judul</th>
                            <th>users</th>
                            <th>status</th>
                            <th>created at</th>
                            <th>view detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e=>$dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($e+1); ?></td>
                            <td><?php echo e($dt->judul); ?></td>
                            <td><?php echo e($dt->users_r->name); ?></td>
                            <td>
                                <?php if($dt->status == null): ?>
                                <label class="label label-warning">Belum Dibaca</label>
                                <?php else: ?>
                                <label class="label label-success">Sudah Dibaca</label>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(date('d F Y H:i:s',strtotime($dt->created_at))); ?></td>
                            <td>
                                <a href="<?php echo e(url('pesan/'.$dt->id)); ?>" class="btn btn-primary btn-xs btn-flat">Detail Pesan</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('scripts'); ?>
 
<script type="text/javascript">
    $(document).ready(function(){
 
        // btn refresh
        $('.btn-refresh').click(function(e){
            e.preventDefault();
            $('.preloader').fadeIn();
            location.reload();
        })
 
    })
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ppdb/resources/views/dashboard/pesan/index.blade.php ENDPATH**/ ?>