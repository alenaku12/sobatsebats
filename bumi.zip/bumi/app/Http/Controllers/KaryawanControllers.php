<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class KaryawanControllers extends Controller
{
    public function index()
    {
        $data = User::all();
        // dd($data);
        return view('karyawan.index', compact('data'));
    }
    public function input()
    {

        return view('karyawan.tambahkaryawan');
    }
}
